# Home - MII IG Meta v2026.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/modul-meta/ImplementationGuide/mii-ig-meta | *Version*:2026.0.0 |
| Active as of 2026-07-23 | *Computable Name*:MII_IG_Meta |

# MII IG Modul Meta

Feel free to modify this index page with your own awesome content!

